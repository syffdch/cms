<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Saran extends CI_Controller {
    public function __construct(){
        parent::__construct();
    }

    public function index() {
        $this->db->from('konfigurasi');
        $konfig = $this->db->get()->row();
        $this->db->from('kategori');
        $kategori = $this->db->get()->result_array();
        $data = array(
            'judul'     => "Contact",
            'konfig'    => $konfig,
            'kategori'  => $kategori,
        );
        $this->load->view('saran', $data);  
    }
    public function insert(){
        $data = array(
            'nama'      => $this->input->post('nama'),
            'email'     => $this->input->post('email'),
            'tanggal'   => date('Y-m-d'),
            'isi_saran' => $this->input->post('isi_saran'),
        );
        $this->db->insert('saran', $data);
        redirect('saran');
    }
}