<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class RecentLogin extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->model('User_model');
        if($this->session->userdata('level')<>'admin'){
			redirect ('auth');
		}
    }
    public function index(){
        $login = $this->db->from('recent_login')->join('user', 'recent_login.user = user.usn')->limit(5)->order_by('id_recent DESC')->get_where('', array('status' => 'Login'))->result_array();
        $logout = $this->db->from('recent_login')->join('user', 'recent_login.user = user.usn')->limit(5)->order_by('id_recent DESC')->get_where('', array('status' => 'Logout'))->result_array();
        $data = array(
            'judul_halaman' => "Recent Login",
            'login'         => $login,
            'logout'        => $logout,
        );
		$this->template->load('template_admin', 'admin/recent_login', $data);
    }
}