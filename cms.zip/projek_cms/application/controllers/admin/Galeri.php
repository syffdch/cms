<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Galeri extends CI_Controller {
    public function __construct(){
       parent::__construct(); 
       if($this->session->userdata('level')==NULL){
        redirect('auth');   
       }
    }
	public function index(){
        $this->db->from('galeri');
        $this->db->order_by('tanggal','DESC');
        $galeri = $this->db->get()->result_array();
        $data = array(
            'judul_halaman' => 'Halaman Galeri',
            'galeri'        =>  $galeri,
        );
		$this->template->load('template_admin','admin/galeri',$data);
	}
    public function simpan(){
        $namafoto                  = date('YmdHis').'.jpg';
        $config['upload_path']     = 'assets/upload/galeri/';
        $config['file_name']       = $namafoto;
        $config['allowed_types']   = '*';
        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('foto')){
            $error = array('error' => $this->upload->display_errors());
        }else{
            $data = array('upload_data' => $this->upload->data());
        }  

        $this->db->from('galeri');
        $this->db->where('judul',$this->input->post('judul'));
        $cek = $this->db->get()->result_array();
        if($cek<>NULL){
        $this->session->set_flashdata('alert','
        <div class="alert alert-dark alert-dismissible mb-9" role="alert">
          judul foto sudah ada.
        </div>
        ');
        redirect('admin/galeri');
        }  
        $data = array(
            'judul'           => $this->input->post('judul'),
            'id_galeri'       => $this->input->post('id_galeri'),
            'tanggal'         => date('Y-m-d'),
            'foto'            => $namafoto
        );
        $this->db->insert('galeri',$data);
        $this->session->set_flashdata('alert','
        <div class="alert alert-dark alert-dismissible mb-9" role="alert">
          Berhasil menambahkan foto.
            <button type="button" class="btn " data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        ');
        redirect('admin/galeri');
    }
    public function update(){
        $namafoto                       = $this->input->post('nama_foto');
        $config['upload_path']          = 'assets/upload/galeri/';
        $config['file_name']            = $namafoto;
        $config['overwrite']            = true;
        $config['allowed_types']        = '*';
        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('foto')){
            $error = array('error' => $this->upload->display_errors());
        }else{
            $data = array('upload_data' => $this->upload->data());
        }  
        $data = array(
            'judul'           => $this->input->post('judul'),
            'id_galeri'       => $this->input->post('id_galeri'),
        );
        $where = array(
            'foto'            => $this->input->post('nama_foto')
        );
        $this->db->update('galeri',$data,$where);
        $this->session->set_flashdata('alert','
            <div class="alert alert-dark alert-dismissible mb-9" role="alert">
            Berhasil memperbarui foto.
            </div>
        ');
        redirect('admin/galeri');
    }
    public function delete_data($id){
        $filename=FCPATH.'/assets/upload/galeri/'.$id;
            if (file_exists($filename)){
                unlink("./assets/upload/galeri/".$id);
            }
        $where = array(
            'foto' => $id
        );
        $this->db->delete('galeri', $where);
        $this->session->set_flashdata('alert','
            <div class="alert alert-dark alert-dismissible mb-9" role="alert">
            Berhasil menghapus foto.
            </div>'
        );
        redirect('admin/galeri');
    }
} 
