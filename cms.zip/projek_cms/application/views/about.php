<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Fashi Template">
    <meta name="keywords" content="Fashi, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>S D C</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="<?= base_url('assets/front')?>/css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/front')?>/css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/front')?>/css/themify-icons.css" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/front')?>/css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/front')?>/css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/front')?>/css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/front')?>/css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/front')?>/css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/front')?>/css/style.css" type="text/css">
    <link rel="shortcut icon" href="<?= base_url('assets/front')?>/img/favicon.png" />
</head>

<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Header Section Begin -->
    <header class="header-section">
        <div class="header-top">
            <div class="container">
                <div class="ht-left mt-3">
                    <i><?= $konfig->judul_website; ?></i>
                </div>
                <div class="ht-right">
                    <a href="<?= base_url('auth')?>" class="login-panel"><i class="fa fa-user"></i>Login</a>
                </div>
                <div class="ht-right col-2">
                    <a href="<?= base_url('')?>" class="login-panel"><i class="fa fa-book"></i>User Guide</a>
                </div>
            </div>
        </div>

        <!-- <div class="container">
            <div class="inner-header">
                <div class="row">
                    <div class="col-lg-2 col-md-2">
                        <div class="logo">
                            <a href="./index.html">
                                <img src="<?= base_url('assets/front')?>/img/logo.png" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->

        <div class="nav-item">
            <div class="container">
                <nav class="nav-menu mobile-menu">
                    <ul>
                        <li><a href="<?= base_url('home/index')?>">Homepage</a></li>
                        <li><a href="">Categories</a>
                            <ul class="dropdown">
                                <?php foreach ($kategori as $kate) { ?>
                                <li><a href="<?= base_url('home/kategori/'. $kate['id_kategori']); ?>"><?= $kate['nama_kategori']; ?></a></li>
                                <?php } ?>
                            </ul>
                        </li>
                        <li><a href="<?= base_url('home/galeri')?>">Gallery</a></li>
                        <li><a href="<?= base_url('home/about')?>">About</a></li>
                        <li><a href="<?= base_url('saran')?>">Contact</a></li>
                    </ul>
                </nav>
                <div id="mobile-menu-wrap"></div>
            </div>
        </div>
    </header>
    <!-- Header End -->

    <!-- Breadcrumb Section Begin -->
    <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <a href="<?= base_url('home/index')?>"><i class="fa fa-home"></i> Home</a>
                        <span><?= $judul; ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section Begin -->

    <!-- Hero Section Begin -->
    <!-- <section class="hero-section">
        <div class="hero-items owl-carousel">
            <?php $no=1; foreach ($caraousel as $aa) { ?>
                <div class="carousel-item <?php if($no==1){ echo 'active'; } ?>">
                <img src="<?= base_url('assets/upload/caraousel/') .$aa['foto']  ?>" class="d-block w-100" alt="...">
                </div>
            <?php $no++; } ?>
        </div>
    </section> -->
    <!-- Hero Section End -->

    <!-- Contact Section Begin -->
    <section class="contact-section spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="content col-12">
                        <div class="contact-title">
                            <h4>Hi! I'm Cipaa</h4>
                            <div class="col-lg-5 mx-auto">
                                <img src="<?= base_url('assets/front')?>/img/foto/me.jpg" class="img-fluid w-100 mb-4 rounded-lg">
                            </div>
                            <p>My full name is Syifa Dila Chairunisa. i'm 16 years old. now i'm in 11th grade, at SMK Negeri 2 Karanganyar, majoring in game software development. my goal is to be a psychologist, wkwkwk it doesn't fit my major, right?. </p>
                        </div>
                        <div class="contact-title">
                            <h4>Fav Song:</h4>
                        </div>
                        <div class="row">
                            <div class="col-lg">
                            <iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/2X3UgVLSA4wYriGIQyYmMA?utm_source=generator" width="100%" height="152" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>
                            </div>
                            <div class="col-lg">
                                <iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/1dGr1c8CrMLDpV6mPbImSI?utm_source=generator" width="100%" height="152" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>
                            </div>
                            <div class="col-lg">
                                <iframe style="border-radius:12px" src="https://open.spotify.com/embed/track/32Pdf9eyXDEMoClEJW6yYP?utm_source=generator" width="100%" height="152" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Contact Section End -->
    
    <!-- Footer Section Begin -->
    <footer class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="footer-left">
                        <div class="footer-logo">
                            <a href="#"><img src="<?= base_url('assets/front')?>/img/logo.png" alt=""></a>
                        </div>
                        <ul>
                            <?= $konfig->profil_website; ?>
                        </ul>
                        <p><?= $konfig->alamat; ?></p>
                        <p><?= $konfig->email; ?></p>
                        <div class="footer-social">
                            <a href="<?= $konfig->facebook; ?>"><i class="fa fa-facebook"></i></a>
                            <a href="<?= $konfig->instagram; ?>"><i class="fa fa-instagram"></i></a>
                            <a href="<?= $konfig->twitter; ?>"><i class="fa fa-twitter"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 offset-lg-1">
                    <div class="footer-widget">
                        <h5>Quick Links</h5>
                        <ul>
                            <li><a href="">Homepage</a></li>
                            <?php foreach ($kategori as $kate) { ?>
                                <li>
                                    <a href="<?= base_url('home/kategori/'. $kate['id_kategori']); ?>"><?= $kate['nama_kategori']; ?></a>
                                </li>
                            <?php } ?>
                            <li><a href="<?= base_url('home/about')?>">About</a></li>
                            <li><a href="<?= base_url('saran')?>">Contact</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright-reserved">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="copyright-text">
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                            Copyright &copy;<script>document.write(new Date().getFullYear());</script>. SDC
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="<?= base_url('assets/front')?>/js/jquery-3.3.1.min.js"></script>
    <script src="<?= base_url('assets/front')?>/js/bootstrap.min.js"></script>
    <script src="<?= base_url('assets/front')?>/js/jquery-ui.min.js"></script>
    <script src="<?= base_url('assets/front')?>/js/jquery.countdown.min.js"></script>
    <script src="<?= base_url('assets/front')?>/js/jquery.nice-select.min.js"></script>
    <script src="<?= base_url('assets/front')?>/js/jquery.zoom.min.js"></script>
    <script src="<?= base_url('assets/front')?>/js/jquery.dd.min.js"></script>
    <script src="<?= base_url('assets/front')?>/js/jquery.slicknav.js"></script>
    <script src="<?= base_url('assets/front')?>/js/owl.carousel.min.js"></script>
    <script src="<?= base_url('assets/front')?>/js/main.js"></script>
</body>

</html>