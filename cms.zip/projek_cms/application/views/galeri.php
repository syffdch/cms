<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Fashi Template">
    <meta name="keywords" content="Fashi, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>S D C</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="<?= base_url('assets/front')?>/css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/front')?>/css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/front')?>/css/themify-icons.css" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/front')?>/css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/front')?>/css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/front')?>/css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/front')?>/css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/front')?>/css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/front')?>/css/style.css" type="text/css">
    <link rel="shortcut icon" href="<?= base_url('assets/front')?>/img/favicon.png" />
</head>

<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Header Section Begin -->
    <header class="header-section">
        <div class="header-top">
            <div class="container">
                <div class="ht-left mt-3">
                    <i><?= $konfig->judul_website; ?></i>
                </div>
                <div class="ht-right">
                    <a href="<?= base_url('auth')?>" class="login-panel"><i class="fa fa-user"></i>Login</a>
                </div>
                <div class="ht-right col-2">
                    <a href="<?= base_url('')?>" class="login-panel"><i class="fa fa-book"></i>User Guide</a>
                </div>
            </div>
        </div>

        <!-- <div class="container">
            <div class="inner-header">
                <div class="row">
                    <div class="col-lg-2 col-md-2">
                        <div class="logo">
                            <a href="./index.html">
                                <img src="<?= base_url('assets/front')?>/img/logo.png" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->

        <div class="nav-item">
            <div class="container">
                <nav class="nav-menu mobile-menu">
                    <ul>
                        <li><a href="<?= base_url('home/index')?>">Homepage</a></li>
                        <li><a href="">Categories</a>
                            <ul class="dropdown">
                                <?php foreach ($kategori as $kate) { ?>
                                <li><a href="<?= base_url('home/kategori/'. $kate['id_kategori']); ?>"><?= $kate['nama_kategori']; ?></a></li>
                                <?php } ?>
                            </ul>
                        </li>
                        <li><a href="<?= base_url('home/galeri')?>">Gallery</a></li>
                        <li><a href="<?= base_url('home/about')?>">About</a></li>
                        <li><a href="<?= base_url('saran')?>">Contact</a></li>
                    </ul>
                </nav>
                <div id="mobile-menu-wrap"></div>
            </div>
        </div>
    </header>
    <!-- Header End -->

    <!-- Breadcrumb Section Begin -->
    <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <a href="<?= base_url('home/index')?>"><i class="fa fa-home"></i> Home</a>
                        <span><?= $judul; ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section Begin -->

    <!-- Hero Section Begin -->
    <!-- <section class="hero-section">
        <div class="hero-items owl-carousel">
            <?php $no=1; foreach ($caraousel as $aa) { ?>
                <div class="carousel-item <?php if($no==1){ echo 'active'; } ?>">
                <img src="<?= base_url('assets/upload/caraousel/') .$aa['foto']  ?>" class="d-block w-100" alt="...">
                </div>
            <?php $no++; } ?>
        </div>
    </section> -->
    <!-- Hero Section End -->

    <!-- Blog Section Begin -->
    <section class="blog-section spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2>Gallery</h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <!-- <div class="col-lg-3 col-md-6 col-sm-8 order-2 order-lg-1">
                    <div class="blog-sidebar">
                        <div class="search-form">
                            <h4>Search</h4>
                            <form action="#">
                                <input type="text" placeholder="Search . . .  ">
                                <button type="submit"><i class="fa fa-search"></i></button>
                            </form>
                        </div>
                        <div class="blog-catagory">
                            <h4>Categories</h4>
                            <ul>
                                <?php foreach ($galeri as $kate) { ?>
                                    <li>
                                        <a href="<?= base_url('home/kategori/'. $kate['id_kategori']); ?>"><?= $kate['nama_kategori']; ?></a>
                                    </li>
                                <?php } ?>
                            </ul>
                        </div>
                        <div class="recent-post">
                            <h4>Latest Article</h4>
                            <div class="recent-blog">
                                <a href="#" class="rb-item">
                                    <div class="rb-pic">
                                        <img src="<?= base_url('assets/front')?>/img/blog/recent-1.jpg" alt="">
                                    </div>
                                    <div class="rb-text">
                                        <h6>The Personality Trait That Makes...</h6>
                                        <p>Fashion <span>- May 19, 2019</span></p>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div> -->
                <div class="col-lg-7">
                    <div class="row">
                    <?php foreach ($galeri as $uu) { ?>
                        <div class="col-sm-6">
                            <div class="blog-item">
                                <div class="bi-pic">
                                    <img src="<?= base_url('assets/upload/galeri/') .$uu['foto']  ?>" alt="">
                                </div>
                                <h5><?= $uu['judul'];?></h5>
                                <div class="text">
                                    <p  class="fa fa-calendar-o"></p> <?= date('M d, Y', strtotime($uu['tanggal'])); ?>
                                </div>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Blog Section End -->
    
    <!-- Footer Section Begin -->
    <footer class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="footer-left">
                        <div class="footer-logo">
                            <a href="#"><img src="<?= base_url('assets/front')?>/img/logo.png" alt=""></a>
                        </div>
                        <ul>
                            <?= $konfig->profil_website; ?>
                        </ul>
                        <p><?= $konfig->alamat; ?></p>
                        <p><?= $konfig->email; ?></p>
                        <div class="footer-social">
                            <a href="<?= $konfig->facebook; ?>"><i class="fa fa-facebook"></i></a>
                            <a href="<?= $konfig->instagram; ?>"><i class="fa fa-instagram"></i></a>
                            <a href="<?= $konfig->twitter; ?>"><i class="fa fa-twitter"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 offset-lg-1">
                    <div class="footer-widget">
                        <h5>Quick Links</h5>
                        <ul>
                            <li><a href="">Homepage</a></li>
                            <?php foreach ($kategori as $kate) { ?>
                                <li>
                                    <a href="<?= base_url('home/kategori/'. $kate['id_kategori']); ?>"><?= $kate['nama_kategori']; ?></a>
                                </li>
                            <?php } ?>
                            <li><a href="<?= base_url('home/about')?>">About</a></li>
                            <li><a href="<?= base_url('saran')?>">Contact</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright-reserved">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="copyright-text">
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                            Copyright &copy;<script>document.write(new Date().getFullYear());</script>. SDC
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="<?= base_url('assets/front')?>/js/jquery-3.3.1.min.js"></script>
    <script src="<?= base_url('assets/front')?>/js/bootstrap.min.js"></script>
    <script src="<?= base_url('assets/front')?>/js/jquery-ui.min.js"></script>
    <script src="<?= base_url('assets/front')?>/js/jquery.countdown.min.js"></script>
    <script src="<?= base_url('assets/front')?>/js/jquery.nice-select.min.js"></script>
    <script src="<?= base_url('assets/front')?>/js/jquery.zoom.min.js"></script>
    <script src="<?= base_url('assets/front')?>/js/jquery.dd.min.js"></script>
    <script src="<?= base_url('assets/front')?>/js/jquery.slicknav.js"></script>
    <script src="<?= base_url('assets/front')?>/js/owl.carousel.min.js"></script>
    <script src="<?= base_url('assets/front')?>/js/main.js"></script>
</body>

</html>