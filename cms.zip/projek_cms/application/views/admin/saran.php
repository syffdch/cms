<div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
		<div class="card-body">
			<h4 class="card-title">Saran</h4>
			<div class="table-responsive">
				<table class="table table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Isi</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $no=1; foreach($saran as $aa) { ?> 
                        <tr>
                            <td ><?= $no; ?></td>
                            <td><?= $aa['tanggal'] ?></td>
                            <td><?= $aa['nama'] ?></td>
                            <td><?= $aa['email'] ?></td>
                            <td>
                                <a type="button" data-toggle="modal" data-target="#modalEdit<?= $aa['id_saran']; ?>" class="text-info">
                                    <span class="mdi mdi-comment-search-outline">Lihat Isi</span>
                                </a>
                            </td>
                            <div class="modal fade" id="modalEdit<?= $aa['id_saran']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalFormTitle" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalFormTitle">Pesan</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">×</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <h3><?= $aa['isi_saran']; ?></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <td>
                                <a href="<?php echo site_url('admin/saran/delete_data/'.$aa['id_saran']); ?>" class="btn btn-sm btn-danger" onclick="return confirm('apakah anda yakin menghapus data ini')">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                    <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5Zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5Zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6Z"/>
                                    <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1ZM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118ZM2.5 3h11V2h-11v1Z"/>
                                </svg>
                                </a>
                            </td>
                        </tr>
                        <?php $no++; } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>