<h2>Dashboard</h2>
<?= $this->session->userdata('nama'); ?>