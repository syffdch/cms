<div id="menghilang">
	<?= $this->session->flashdata('alert') ?>
</div>

<div class="col-lg-12 col-md-12">
    <div class="mt-1 mb-3">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Tabel Aktivitas Login & Logout</h4>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Username</th>
                                <th>Nama</th>
                                <th>Jam</th>
                                <th>Tanggal</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                            <?php $no=1; foreach($login as $aa) { ?>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td><?= $aa['user']; ?></td>
                                <td><?= $aa['nama']; ?></td>
                                <td><?= $aa['waktu']; ?></td>
                                <td><?= $aa['tanggal']; ?></td>
                                <td>
                                    <?php if ($ser['status'] == 'Login') : ?>
                                        <button class="badge badge-pill badge-success"><?= $ser['status']; ?></button>
                                    <?php elseif ($ser['status'] == 'Logout') : ?>
                                        <button class="badge badge-pill badge-danger"><?= $ser['status']; ?></button>
                                    <?php else : ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php $no++; } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>