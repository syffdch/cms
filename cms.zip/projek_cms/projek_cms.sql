-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2023 at 02:25 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projek_cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `caraousel`
--

CREATE TABLE `caraousel` (
  `id_caraousel` int(11) NOT NULL,
  `judul` varchar(60) NOT NULL,
  `foto` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `caraousel`
--

INSERT INTO `caraousel` (`id_caraousel`, `judul`, `foto`) VALUES
(12, 'me', '20231205042950.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `galeri`
--

CREATE TABLE `galeri` (
  `id_galeri` int(11) NOT NULL,
  `judul` varchar(30) NOT NULL,
  `foto` varchar(30) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `galeri`
--

INSERT INTO `galeri` (`id_galeri`, `judul`, `foto`, `tanggal`) VALUES
(0, 'Pengukuhan Pengurus OSIS', '20231205031153.jpg', '2023-12-05'),
(5, 'Pengurus OSIS MB. 2023/2024', '20231205031254.jpg', '2023-12-05'),
(6, 'Hari Guru', '20231205033522.jpg', '2023-12-05'),
(7, 'Purna Pengurus OSIS MB. 22/23', '20231205033749.jpg', '2023-12-05');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES
(4, 'Sejarah'),
(11, 'Bahasa Jawa'),
(14, 'BTS'),
(15, 'Agama');

-- --------------------------------------------------------

--
-- Table structure for table `konfigurasi`
--

CREATE TABLE `konfigurasi` (
  `id_konfigurasi` int(11) NOT NULL,
  `judul_website` varchar(60) NOT NULL,
  `profil_website` text NOT NULL,
  `facebook` varchar(50) NOT NULL,
  `instagram` varchar(50) NOT NULL,
  `twitter` varchar(50) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `konfigurasi`
--

INSERT INTO `konfigurasi` (`id_konfigurasi`, `judul_website`, `profil_website`, `facebook`, `instagram`, `twitter`, `alamat`, `email`) VALUES
(1, 'Cipaa\'s Website CMS', '<p>Hi! my name is Syifa Dila Chairunisa.&nbsp;</p>', 'https://facebook.com/syifadilachairunisa', 'https://instagram.com/syffdch', 'https://twitter.com/usersdc', 'Perum. Griya Gamersi Lalung, Manggeh Anyar, Karanganyar', 'syifadilach14@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `konten`
--

CREATE TABLE `konten` (
  `id_konten` int(11) NOT NULL,
  `judul` varchar(200) NOT NULL,
  `id_kategori` varchar(20) NOT NULL,
  `isi_konten` text NOT NULL,
  `tanggal` date NOT NULL,
  `username` varchar(60) NOT NULL,
  `foto` varchar(30) NOT NULL,
  `slug` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `konten`
--

INSERT INTO `konten` (`id_konten`, `judul`, `id_kategori`, `isi_konten`, `tanggal`, `username`, `foto`, `slug`) VALUES
(9, 'Proklamasi Kemerdekaan Indonesia', '4', '<p class=\"MsoNormal\" style=\"margin-bottom: 0in; text-align: justify; text-indent: .5in; line-height: 150%;\"><span style=\"font-size: 14pt;\"><span style=\"line-height: 150%; font-family: \'Times New Roman\', serif; color: rgb(51, 51, 51); background: white;\">Kemerdekaan Indonesia merupakan hasil perjuangan dan pengobanan para leluhur. Berbagai peristiwa penting menjadi latar belakang kemerdekaan Indonesia. Dimulai dari pemboman Kota Hiroshima dan Nagasaki oleh Sekutu hingga peristiwa Rengasdengklok.</span><span style=\"line-height: 150%; font-family: \'Times New Roman\', serif; color: rgb(51, 51, 51);\"><br style=\"box-sizing: border-box; font-variant-ligatures: normal; font-variant-caps: normal; orphans: 2; text-align: start; widows: 2; -webkit-text-stroke-width: 0px; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; word-spacing: 0px;\"><br style=\"box-sizing: border-box; font-variant-ligatures: normal; font-variant-caps: normal; orphans: 2; text-align: start; widows: 2; -webkit-text-stroke-width: 0px; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; word-spacing: 0px;\"><strong><span style=\"background: white;\"><span style=\"font-variant-ligatures: normal; font-variant-caps: normal; orphans: 2; text-align: start; widows: 2; -webkit-text-stroke-width: 0px; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; float: none; word-spacing: 0px;\">Penyerangan Jepang oleh Sekutu</span></span></strong></span></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0in; text-align: justify; text-indent: .5in; line-height: 150%;\"><span style=\"font-size: 14pt;\"><span style=\"line-height: 150%; font-family: \'Times New Roman\', serif; color: rgb(51, 51, 51); background: white;\">Setelah menjajah Indonesia sejak 1942 silam, Jepang takluk di tangan sekutu Belanda pada 15 Agustus 1945. Berita kekalahan Jepang pun terdengar bersamaan dengan persiapan kemerdekaan Indonesia.</span><span style=\"line-height: 150%; font-family: \'Times New Roman\', serif; color: rgb(51, 51, 51);\"> <span style=\"background: white;\">Golongan muda yang dipimpin oleh Chaerul Saleh kemudian mendesak Soekarno dan Mohammad Hatta untuk mendeklarasikan kemerdekaan Indonesia.</span></span></span><br style=\"mso-special-character: line-break; box-sizing: border-box; font-variant-ligatures: normal; font-variant-caps: normal; orphans: 2; text-align: start; widows: 2; -webkit-text-stroke-width: 0px; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; word-spacing: 0px;\"><span style=\"font-size: 14pt;\"><!-- [if !supportLineBreakNewLine]--></span><br style=\"mso-special-character: line-break;\"><span style=\"font-size: 14pt;\"><!--[endif]--></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0in; text-align: justify; line-height: 150%;\"><span style=\"font-size: 14pt;\"><strong><span style=\"line-height: 150%; font-family: \'Times New Roman\', serif; color: rgb(51, 51, 51); background: white;\">Peristiwa Rengasdengklok</span></strong></span></p>\r\n<p class=\"MsoNormal\" style=\"text-align: justify; text-indent: .5in; line-height: 150%;\"><span style=\"font-size: 14pt;\"><span style=\"line-height: 150%; font-family: \'Times New Roman\', serif; color: rgb(51, 51, 51); background: white;\">Sejarah Kemerdekaan Indonesia juga tidak lepas dari peristiwa Rengasdengklok. Peristiwa ini terjadi sebelum proklamasi kemerdekaan Indonesia, tepatnya pada 16 Agustus 1945. Setelah berita kekalahan Jepang menyerah tanpa syarat pada sekutu. Sutan Syahrir (golongan muda) mendesak Mohammad Hatta secepatnya memproklamasikan kemerdekaan Indonesia. Namun usul Syahrir ditolak karena proklamasi kemerdekaan Indonesia diserahkan pada PPKI (Panitia Persiapan Kemerdekaan Indonesia). Tetapi, golongan muda berpendapat kemerdekaan harus diraih dan diperjuangkan sendiri, tanpa ikut campur dari tangan Jepang. Golongan muda menganggap PPKI adalah organisasi bentukan Jepang meski anggotanya orang Indonesia. Golongan muda ingin kemerdekaan Indonesia tanpa campur tangan Jepang. Ir.</span><span style=\"line-height: 150%; font-family: \'Times New Roman\', serif; color: rgb(51, 51, 51);\"> <span style=\"background: white;\">Sokerno dan Drs. Moh. Hatta kemudian dibawa ke luar kota untuk menjauhkan pengaruh Jepang. Golongan muda khawatir kedua tokoh ini akan dipengaruhi oleh Jepang untuk menghalangi proklamasi kemerdekaan.</span></span></span></p>\r\n<p class=\"MsoNormal\" style=\"text-align: justify; text-indent: .5in; line-height: 150%;\"><span style=\"font-size: 14pt;\"><span style=\"line-height: 150%; font-family: \'Times New Roman\', serif; color: rgb(51, 51, 51); background: white;\">Soekarno dan Hatta kemudian diamankan di Rengasdengklok atau markas PETA, berada 15 kilometer (km) dari Kedung Gede, Karawang. Sementara itu di Jakarta, Ahmad Soebardjo (golongan tua) bersama Wikana (golongan muda) mengadakan kesepakatan untuk proklamasi di Jakarta. Laksamana Maeda membolehkan rumahnya menjadi tempat perundingan untuk membuat naskah proklamasi. Kesepakatan tersebut membuat Jusuf Kunto dari pihak pemuda membawa Ahmad Subardjo menjemput Ir. Soekarno ke Rengasdengklok.</span><span style=\"line-height: 150%; font-family: \'Times New Roman\', serif; color: rgb(51, 51, 51);\"> </span></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0in; text-align: justify; line-height: 150%;\">&nbsp;</p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0in; text-align: justify; line-height: 150%;\"><span style=\"font-size: 14pt;\"><strong><span style=\"line-height: 150%; font-family: \'Times New Roman\', serif; color: rgb(51, 51, 51); background: white;\">Perumusan Teks Proklamasi</span></strong></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0in; text-align: justify; line-height: 150%;\"><span style=\"font-size: 14pt;\"><span style=\"line-height: 150%; font-family: \'Times New Roman\', serif; color: rgb(51, 51, 51); background: white;\">Malam hari pada 16 Agustus 1945, rombongan sampai ke Jakarta. Soekarno dan Hatta diarahkan untuk menuju rumah Laksamana Maeda dengan maksud menyusun isi teks proklamasi. Sementara di ruang depan, juga ada Sayuti Melik, Soekarno, B. M. Diah, dan Soediro. Tak dapat dipungkiri bahwa saat itu ada intervensi dari prajurit Jepang, yakni Shigetada Nishijima yang menyarankan agar perpindahan kekuasaan hanya dari aspek administratif. Meski begitu, Soekarno tetap bersikeras agar terjadi &ldquo;transfer of power.&rdquo;</span><span style=\"line-height: 150%; font-family: \'Times New Roman\', serif; color: rgb(51, 51, 51);\"> <span style=\"background: white;\">Perdebatan tersebut menghasilkan pemikiran yang berbeda. Akhirnya teks proklamasi ditandatangani oleh Soekarno dan Hatta dengan mengatasnamakan bangsa Indonesia. Kemudian Sayuti Melik menyalin dan mengetik menggunakan mesin tik di kantor perwakilan Angkatan Laut Jerman. Pembacaan Teks proklamasi kemerdekaan Usai teks proklamasi selesai ditulis, terjadilah hari paling bersejarah bagi bangsa Indonesia.</span></span></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0in; text-align: justify; line-height: 150%;\">&nbsp;</p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0in; text-align: justify; line-height: 150%;\"><span style=\"font-size: 14pt;\"><span style=\"line-height: 150%; font-family: \'Times New Roman\', serif; color: rgb(51, 51, 51);\"><span style=\"background: white;\"><strong><span style=\"line-height: 150%; font-family: \'Times New Roman\', serif; color: rgb(51, 51, 51); background: white;\">Pembacaan Teks Proklamasi</span></strong></span></span></span></p>\r\n<p class=\"MsoNormal\" style=\"text-align: justify; text-indent: .5in; line-height: 150%;\"><span style=\"font-size: 14pt; line-height: 150%; font-family: \'Times New Roman\', serif; color: rgb(51, 51, 51); background: white;\">Kemerdekaan Indonesia ditandai dengan pembacaan teks proklamasi oleh Soekarno pada tanggal 17 Agustus 1945. Pembacaan tersebut dihadiri oleh para tokoh pergerakan kemerdekaan dan seluruh rakyat Indonesia. Upacara pembacaan teks proklamasi tersebut berjalan dengan lancar bertempat di kediaman Soekarno di Jalan Pegangsaan Timur No. 56, Jakarta. Beberapa acara telah disusun dalam hari kemerdekaan Indonesia, seperti pengibaran bendera Merah Putih, dan sambutan oleh walikota pada saat itu, yaitu Suwiryo dan Muwardi. Demikian sejarah singkat kemerdekaan Indonesia pada 17 Agustus 1945. Hingga kini, naskah proklamasi disimpan tempat penyimpanan khusus di ANRI.</span></p>', '2023-11-23', 'dilss', '20231123015554.jpg', 'Proklamasi-Kemerdekaan-Indonesia'),
(10, 'Kearifan Lokal : Tetedhan Tradisional Jawa', '11', '<p style=\"text-align: justify;\"><span style=\"font-size: 14pt;\"><span lang=\"EN-AU\" style=\"line-height: 107%; font-family: \'Times New Roman\', serif;\">Getuk yaiku tetedhan tradisional Jawa </span><span lang=\"EN-AU\" style=\"line-height: 107%; font-family: \'Times New Roman\', serif; color: black; background: white;\">sing utamane digawe saking ketela pohung</span><span lang=\"EN-AU\" style=\"line-height: 107%; font-family: \'Times New Roman\', serif; color: black;\">,</span><span lang=\"EN-AU\" style=\"line-height: 107%; font-family: \'Times New Roman\', serif;\"> <span style=\"mso-spacerun: yes;\">&nbsp;</span>asale saking Kabupaten Magelang, Jawa Tengah. Gethuk ngadahi maneka warna rasa, enten sing original, Coklat, keju, lan maneka warna liane.</span></span></p>\r\n<p style=\"text-align: justify; line-height: 1.2;\"><span style=\"font-size: 14pt;\"><!-- [if !supportLists]--><span lang=\"IN\" style=\"line-height: 107%; font-family: \'Times New Roman\', serif;\">Filosofi Gethuk</span></span></p>\r\n<p style=\"text-align: justify;\"><span lang=\"EN-AU\" style=\"font-size: 14pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">Pohong ingkang dipundadosaken bahan utami gethuk nyimbulaken makna prasaja. Pohong saget tuwuh wonten pundi mawon nanging tetep andap manah kanthi mboten nedhahi uwohipun. Dene klapa parut ingkang dados pelengkap segahan gethuk nyimbulaken kebermanfatan. sadayaning perangan wit klapa nggadhahi ginanipun kagem manungsa. saking bab kasebat , manungsa sasaenipun gesang lebeting kebermanfaatan kagem tiyang sanes lan sawentawisipun. kombinasi pohong lan klapa<span style=\"mso-spacerun: yes;\"> </span>menika keparing dipunsimpulaken menawi getuk inggih menika tetedhan tradisional ingkang merefleksikan makna prasaja<span style=\"mso-spacerun: yes;\">&nbsp;&nbsp; </span>lan kebermanfaatan.</span></p>\r\n<p style=\"text-align: justify; line-height: 1.1;\"><span style=\"font-size: 14pt;\"><!-- [if !supportLists]--><span lang=\"IN\" style=\"line-height: 107%; font-family: \'Times New Roman\', serif;\">Caranipun Damel Gethuk</span></span></p>\r\n<p style=\"text-align: justify; line-height: 1.1;\"><span lang=\"EN-AU\" style=\"font-size: 14pt; line-height: 107%; font-family: \'Times New Roman\', serif; color: black; background: white;\">Bahan-bahan:</span></p>\r\n<p style=\"text-align: justify; line-height: 1;\"><span lang=\"EN-AU\" style=\"font-size: 14pt; line-height: 107%; font-family: \'Times New Roman\', serif; color: black; background: white;\">1. 1/2 kg pohong</span></p>\r\n<p style=\"text-align: justify; line-height: 1;\"><span lang=\"EN-AU\" style=\"font-size: 14pt; line-height: 107%; font-family: \'Times New Roman\', serif; color: black; background: white;\">2. gula</span></p>\r\n<p style=\"text-align: justify; line-height: 1;\"><span lang=\"EN-AU\" style=\"font-size: 14pt; line-height: 107%; font-family: \'Times New Roman\', serif; color: black; background: white;\">3. uyah</span></p>\r\n<p style=\"text-align: justify; line-height: 1;\"><span lang=\"EN-AU\" style=\"font-size: 14pt; line-height: 107%; font-family: \'Times New Roman\', serif; color: black; background: white;\">4. glepung</span></p>\r\n<p style=\"text-align: justify; line-height: 1;\"><span lang=\"EN-AU\" style=\"font-size: 14pt; line-height: 107%; font-family: \'Times New Roman\', serif; color: black; background: white;\">5. glepung panir</span></p>\r\n<p style=\"text-align: justify; line-height: 1;\"><span lang=\"EN-AU\" style=\"font-size: 14pt; line-height: 107%; font-family: \'Times New Roman\', serif; color: black; background: white;\">6. banyu</span></p>\r\n<p style=\"text-align: justify; line-height: 1;\"><span style=\"font-size: 14pt;\"><span lang=\"EN-AU\" style=\"line-height: 107%; font-family: \'Times New Roman\', serif; color: black; background: white;\">7. lenga</span><span lang=\"EN-AU\" style=\"line-height: 107%; font-family: \'Times New Roman\', serif; color: black; background: white;\"> </span></span></p>\r\n<p style=\"text-align: justify; line-height: 1.1;\"><span lang=\"EN-AU\" style=\"font-size: 14pt; line-height: 107%; font-family: \'Times New Roman\', serif; color: black; background: white;\">Carane nggawe:</span></p>\r\n<p style=\"text-align: justify; line-height: 1.1;\"><span lang=\"EN-AU\" style=\"font-size: 14pt; line-height: 107%; font-family: \'Times New Roman\', serif; color: black; background: white;\">Langkah 1</span></p>\r\n<p style=\"text-align: justify; line-height: 1.1;\"><span lang=\"EN-AU\" style=\"font-size: 14pt; line-height: 107%; font-family: \'Times New Roman\', serif; color: black; background: white;\">Godhok banyu, banjur di dang singkong nganti empuk. Nalika panas, remuk nganti alus. Tambah gula, uyah. Aduk \"Lan bentuk dadi bunder\". iso di isi rasa liane kaya coklat, keju lan salinan.</span></p>\r\n<p style=\"text-align: justify; line-height: 1.1;\"><span lang=\"EN-AU\" style=\"font-size: 14pt; line-height: 107%; font-family: \'Times New Roman\', serif; color: black; background: white;\">Langkah 2</span></p>\r\n<p style=\"text-align: justify; line-height: 1.1;\"><span lang=\"EN-AU\" style=\"font-size: 14pt; line-height: 107%; font-family: \'Times New Roman\', serif; color: black; background: white;\">Tambah glepung lan banyu ing celepun. Lan nyiyapake mangkuk kanggo glepungng panir .</span></p>\r\n<p style=\"text-align: justify; line-height: 1.1;\"><span lang=\"EN-AU\" style=\"font-size: 14pt; line-height: 107%; font-family: \'Times New Roman\', serif; color: black; background: white;\">Langkah 3</span></p>\r\n<p style=\"text-align: justify;\"><span lang=\"EN-AU\" style=\"font-size: 14pt; line-height: 107%; font-family: \'Times New Roman\', serif;\"><span lang=\"EN-AU\" style=\"line-height: 107%; font-family: \'Times New Roman\', serif; color: black; background: white;\">Panaske lenga, banjur celupake bal pohong ing tepung panir, banjur goreng nganti kecoklatan</span></span></p>', '2023-12-05', 'dilss', '20231205032629.jpg', 'Kearifan-Lokal-:-Tetedhan-Tradisional-Jawa'),
(11, 'Partai Komunis Indonesia', '4', '<p style=\"text-align: justify; line-height: 1.5;\"><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\">Partai Komunis Indonesia atau PKI adalah sebuah partai berideologi komunisme yang pernah ada di Indonesia. Partai ini didirikan pada tahun 1914 oleh tokoh Sosialis Belanda, Hendricus Josephus Franciscus Marie Sneevliet.&nbsp;Pria dengan nama pendek Henk Sneevliet ini merupakan Ketua Serikat Buruh Kereta Api Belanda atau Nederlandse Vereniging van Spoor en Tramweg Personeel (NVSTP). Ruth T. McVey dalam bukunya The Rise of Indonesian Communism menggambarkan Sneevliet sebagai seorang propagandis berbakat dan penuh semangat.</span></p>\r\n<p style=\"text-align: justify; line-height: 1.5;\"><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\"><strong>Sejarah awal mula berdirinya PKI</strong></span></p>\r\n<p style=\"text-align: justify; line-height: 1.5;\"><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\">Pada 9 Mei 1914 Henk Sneevliet mendirikan Indische Sociaal-Democratische Vereeniging (ISDV) atau Persatuan Sosial Demokrat Hindia Belanda. Setahun kemudian anggotanya bertambah menjadi 134 orang. Pada tahun-tahun awal pendiriannya ISDV membatasi aktivitasnya pada diskusi teori masalah kolonial. ISDV kemudian bersalin nama menjadi Partai Komunis Indonesia pada Mei 1920 di Semarang. Semaoen dan Darsono berperan dalam pendirian tersebut.&nbsp;<br></span></p>\r\n<p style=\"text-align: justify; line-height: 1.5;\"><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\"><strong>Tujuan PKI</strong></span></p>\r\n<p style=\"text-align: justify; line-height: 1.5;\"><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\">Untuk menantang imperialisme dan kapitalisme pemerintah Belanda dengan membangun serikat pekerja dan untuk mempromosikan pentingnya kesadaran politik di antara para petani.<br></span></p>\r\n<p style=\"text-align: justify; line-height: 1.5;\"><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\"><strong>Tokoh-tokoh PKI</strong></span></p>\r\n<p style=\"text-align: justify; line-height: 1.5;\"><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\">- Henk Sneevliet<br>- Musso<br>- Dipa Nusantara Aidit<br>- Amir Syarifuddin<br>- Semaun<br>- Njoto<br>- Oetomo Ramelan<br>- Abdul Latief Hendraningrat<br>- Alimin Prawirodirdjo<br>- Darsono<br>- Misbach<br></span></p>\r\n<p style=\"text-align: justify; line-height: 1.5;\"><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\"><strong>Pemberontakan Madiun 1948</strong></span></p>\r\n<p style=\"text-align: justify; line-height: 1.5;\"><span style=\"font-size: 14pt;\"><span style=\"font-family: \'times new roman\', times, serif;\">Pada 18 September 1948, terjadi pemberontakan PKI Madiun bertujuan menggulingkan pemerintahan yang sah yakni Republik Indonesia dan mengganti landasan negara. Gerakan ini diketuai oleh Amir Sjarifuddin dan Muso. Tak hanya berusaha menggulingkan pemerintahan Indonesia, pemberontakan PKI di Madiun juga bertujuan membentuk negara Republik Indonesia Soviet, mengganti dasar negara Pancasila dengan Komunisme, dan mengajak petani dan buruh untuk melakukan pemberontakan. Kemudian pada 20 September 1948 dilakukan operasi penumpasan yang dipimpin oleh Kolonel A.H. Nasution. Dalam operasi ini, Musso, Amir dan para tokoh komunis lainnya ditemukan dan dijatuhi hukuman mati.</span><span style=\"font-family: \'times new roman\', times, serif;\"><br></span></span></p>\r\n<p style=\"text-align: justify; line-height: 1.5;\"><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\"><strong>Gerakan 30 September</strong></span></p>\r\n<p style=\"text-align: justify; line-height: 1.5;\"><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\">Gerakan 30 September atau G30S PKI merupakan gerakan yang dipimpin oleh DN Aidit untuk menggulingkan pemerintahan Presiden Sukarno dan mengubah Indonesia menjadi negara komunis. Peristiwa kelam dalam sejarah Indonesia ini terjadi pada 1 Oktober 1965 dini hari, saat Letkol Untung yang merupakan anggota Cakrabirawa (pasukan pengawal Istana) memimpin pasukan yang dianggap loyal pada PKI. Gerakan ini mengincar perwira tinggi TNI AD Indonesia. Tiga dari enam orang yang menjadi target langsung dibunuh di kediamannya. Sedangkan lainnya diculik dan dibawa menuju Lubang Buaya.<br></span></p>', '2023-12-05', 'dilss', '20231205060218.jpg', 'Partai-Komunis-Indonesia'),
(12, 'Bangtan Sonyeondan', '14', '<p>Bangtan Boys atau yang dikenal juga dengan nama BTS adalah salah satu&nbsp;<em>idol group</em>&nbsp;asal Korea Selatan yang memulai debutnya pada 13 Juni 2013 dengan single&nbsp;<em>No More&nbsp;Dream</em>. Single debut ini merupakan salah satu single dalam album perdana mereka yang bertajuk&nbsp;<em>2 Cool 4 Skool</em>. <em>Idol group</em> yang berada di bawah naungan Big Hit Entertainment ini beranggotakan tujuh orang. Profil member BTS tersebut adalah Kim Namjoon, Kim Seokjin, Min Yoongi, Jung Hoseok, Park Jimin, Kim Taehyung, dan Jeon Jungkook.</p>\r\n<p>Album pertama yang dirilisnya ini berhasil mengantarkan mereka untuk meraih penghargaan New Artist of the Year dari MelOn Music Awards dan Golden Disk Awards pada tahun 2013. Grup ini dikenal memiliki basis penggemar yang sangat besar di seluruh dunia.&nbsp;<em>Fandom</em>-nya memiliki julukan ARMY yang merupakan singkatan dari&nbsp;<em>Adorable Representative MC for Youth</em>.&nbsp;Jumlah fans-nya di seluruh dunia pun semakin hari kian bertambah. Kehadirannya juga semakin mendulang perhatian publik lantaran lagu lagu BTS selalu berhasil menempati posisi puncak&nbsp;<em>chart</em> musik di berbagai negara.</p>', '2023-12-05', 'dilss', '20231205062053.jpg', 'Bangtan-Sonyeondan');

-- --------------------------------------------------------

--
-- Table structure for table `recent_login`
--

CREATE TABLE `recent_login` (
  `id_recent` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `waktu` time NOT NULL,
  `tanggal` date NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `saran`
--

CREATE TABLE `saran` (
  `id_saran` int(11) NOT NULL,
  `isi_saran` text NOT NULL,
  `tanggal` date NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `saran`
--

INSERT INTO `saran` (`id_saran`, `isi_saran`, `tanggal`, `nama`, `email`) VALUES
(11, 'da', '2023-12-05', 'sy', 'syifa@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `usn` varchar(60) NOT NULL,
  `pas` varchar(32) NOT NULL,
  `nama` varchar(40) NOT NULL,
  `level` enum('admin','kontributor') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `usn`, `pas`, `nama`, `level`) VALUES
(1, 'dilss', '81dc9bdb52d04dc20036dbd8313ed055', 'Syifa Dila', 'admin'),
(8606, 'mwl', '81dc9bdb52d04dc20036dbd8313ed055', 'Ibrahim', 'kontributor'),
(8607, 'pipapip', '81dc9bdb52d04dc20036dbd8313ed055', 'Afif', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `caraousel`
--
ALTER TABLE `caraousel`
  ADD PRIMARY KEY (`id_caraousel`);

--
-- Indexes for table `galeri`
--
ALTER TABLE `galeri`
  ADD PRIMARY KEY (`id_galeri`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `konfigurasi`
--
ALTER TABLE `konfigurasi`
  ADD PRIMARY KEY (`id_konfigurasi`);

--
-- Indexes for table `konten`
--
ALTER TABLE `konten`
  ADD PRIMARY KEY (`id_konten`);

--
-- Indexes for table `recent_login`
--
ALTER TABLE `recent_login`
  ADD PRIMARY KEY (`id_recent`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `caraousel`
--
ALTER TABLE `caraousel`
  MODIFY `id_caraousel` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `galeri`
--
ALTER TABLE `galeri`
  MODIFY `id_galeri` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `konfigurasi`
--
ALTER TABLE `konfigurasi`
  MODIFY `id_konfigurasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `konten`
--
ALTER TABLE `konten`
  MODIFY `id_konten` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `recent_login`
--
ALTER TABLE `recent_login`
  MODIFY `id_recent` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8608;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
